# Discord-Server-Nuker
Releasing my server nuker (Bypasses Rate Limited &amp; Some Server Protection) It was used to bypass summrs.

This will work ONLY if you have https proxys
